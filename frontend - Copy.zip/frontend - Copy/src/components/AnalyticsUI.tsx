import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, ClipboardCopy, Search, X } from 'lucide-react'
import { useMemo, useState } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { asText } from '../lib/format'
import { useToast } from './Feedback'

export const CHART_COLORS = ['#174ea6', '#0f8b78', '#f59e0b', '#7c3aed', '#dc4f64', '#0891b2', '#64748b', '#84a91d']

const tooltipStyle = {
  border: '1px solid #dce3ec',
  borderRadius: 12,
  boxShadow: '0 12px 32px rgba(23, 41, 68, .12)',
  fontSize: 13,
}

export function MetricCard({ label, value, detail }: { label: string; value: string | number; detail?: string }) {
  return (
    <article className="analytics-metric">
      <small>{label}</small>
      <strong>{value}</strong>
      {detail && <span>{detail}</span>}
    </article>
  )
}

export function DistributionChart({
  title,
  subtitle,
  data,
  kind = 'bar',
  limit = 10,
}: {
  title: string
  subtitle: string
  data: Array<{ name: string; value: number }>
  kind?: 'bar' | 'pie'
  limit?: number
}) {
  const visible = data.slice(0, limit)
  return (
    <article className="chart-card">
      <div className="chart-heading"><h3>{title}</h3><p>{subtitle}</p></div>
      <div className={`chart-container ${kind === 'pie' ? 'pie-container' : ''}`}>
        <ResponsiveContainer width="100%" height="100%">
          {kind === 'pie' ? (
            <PieChart>
              <Pie data={visible} dataKey="value" nameKey="name" innerRadius="55%" outerRadius="78%" paddingAngle={2} stroke="none">
                {visible.map((entry, index) => <Cell key={entry.name} fill={CHART_COLORS[index % CHART_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} formatter={(value) => [Number(value).toLocaleString('id-ID'), 'Jumlah']} />
            </PieChart>
          ) : (
            <BarChart data={visible} layout="vertical" margin={{ top: 4, right: 20, bottom: 4, left: 8 }}>
              <CartesianGrid stroke="#e8edf3" horizontal={false} />
              <XAxis type="number" axisLine={false} tickLine={false} tick={{ fill: '#7a8799', fontSize: 12 }} allowDecimals={false} />
              <YAxis type="category" dataKey="name" width={132} axisLine={false} tickLine={false} tick={{ fill: '#445267', fontSize: 12 }} tickFormatter={(value: string) => value.length > 21 ? `${value.slice(0, 19)}…` : value} />
              <Tooltip contentStyle={tooltipStyle} cursor={{ fill: '#f4f7fb' }} formatter={(value) => [Number(value).toLocaleString('id-ID'), 'Jumlah']} />
              <Bar dataKey="value" fill="#174ea6" radius={[0, 5, 5, 0]} maxBarSize={26} />
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>
      {kind === 'pie' && (
        <div className="chart-legend">
          {visible.map((item, index) => (
            <div key={item.name}><i style={{ background: CHART_COLORS[index % CHART_COLORS.length] }} /><span>{item.name}</span><strong>{item.value.toLocaleString('id-ID')}</strong></div>
          ))}
        </div>
      )}
    </article>
  )
}

export function DataTable({ rows, columns }: { rows: Record<string, unknown>[]; columns: string[] }) {
  const { pushToast } = useToast()
  const [pageSize, setPageSize] = useState(20)
  const [query, setQuery] = useState('')
  const [page, setPage] = useState(0)
  const [sort, setSort] = useState<{ column: string; direction: 'asc' | 'desc' } | null>(null)
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({})
  const [selected, setSelected] = useState<Set<string>>(new Set())

  const indexedRows = useMemo(() => rows.map((row, index) => ({ row, key: `${asText(row.No)}-${index}` })), [rows])

  const filtered = useMemo(() => {
    const term = query.trim().toLocaleLowerCase('id-ID')
    const matching = indexedRows.filter(({ row }) => {
      if (term && !columns.some((column) => asText(row[column]).toLocaleLowerCase('id-ID').includes(term))) return false
      return columns.every((column) => {
        const filter = (columnFilters[column] ?? '').trim().toLocaleLowerCase('id-ID')
        return !filter || asText(row[column]).toLocaleLowerCase('id-ID').includes(filter)
      })
    })
    if (!sort) return matching
    return [...matching].sort((a, b) => {
      const aValue = asText(a.row[sort.column])
      const bValue = asText(b.row[sort.column])
      const numericA = Number(aValue)
      const numericB = Number(bValue)
      const comparison = Number.isFinite(numericA) && Number.isFinite(numericB)
        ? numericA - numericB
        : aValue.localeCompare(bValue, 'id-ID')
      return sort.direction === 'asc' ? comparison : -comparison
    })
  }, [columnFilters, columns, indexedRows, query, sort])

  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize))
  const safePage = Math.min(page, pageCount - 1)
  const visibleRows = filtered.slice(safePage * pageSize, (safePage + 1) * pageSize)
  const allPageSelected = visibleRows.length > 0 && visibleRows.every(({ key }) => selected.has(key))

  const toggleSort = (column: string) => {
    setSort((current) => current?.column === column
      ? { column, direction: current.direction === 'asc' ? 'desc' : 'asc' }
      : { column, direction: 'asc' })
  }

  const togglePage = () => setSelected((current) => {
    const next = new Set(current)
    visibleRows.forEach(({ key }) => allPageSelected ? next.delete(key) : next.add(key))
    return next
  })

  const copySelected = async () => {
    const chosen = indexedRows.filter(({ key }) => selected.has(key)).map(({ row }) => row)
    const text = [columns.join('\t'), ...chosen.map((row) => columns.map((column) => asText(row[column])).join('\t'))].join('\n')
    try {
      await navigator.clipboard.writeText(text)
      pushToast(`${chosen.length} baris disalin.`, 'success')
    } catch {
      pushToast('Data terpilih gagal disalin.', 'error')
    }
  }

  return (
    <section className="panel table-panel">
      <div className="table-toolbar">
        <div><h3>Data rinci</h3><p>{filtered.length.toLocaleString('id-ID')} baris ditemukan · {selected.size} dipilih</p></div>
        <div className="table-actions">
          <button type="button" disabled={!filtered.length} onClick={() => setSelected(new Set(filtered.map(({ key }) => key)))}>Pilih semua hasil</button>
          <button type="button" disabled={!selected.size} onClick={() => void copySelected()}><ClipboardCopy size={15} /> Salin</button>
          <button type="button" disabled={!selected.size} onClick={() => setSelected(new Set())}><X size={15} /> Kosongkan</button>
          <label className="search-field table-search"><Search size={17} /><input value={query} onChange={(event) => { setQuery(event.target.value); setPage(0) }} placeholder="Cari semua kolom…" /></label>
        </div>
      </div>
      <div className="table-scroll">
        <table>
          <thead>
            <tr><th className="select-column"><input type="checkbox" aria-label="Pilih semua di halaman ini" checked={allPageSelected} onChange={togglePage} /></th>{columns.map((column) => <th key={column}><button type="button" onClick={() => toggleSort(column)}>{column}<span>{sort?.column === column ? sort.direction === 'asc' ? '↑' : '↓' : ''}</span></button></th>)}</tr>
            <tr className="filter-row"><th className="select-column" />{columns.map((column) => <th key={column}><input value={columnFilters[column] ?? ''} onChange={(event) => { setColumnFilters((current) => ({ ...current, [column]: event.target.value })); setPage(0) }} placeholder={`Filter ${column}`} aria-label={`Filter ${column}`} /></th>)}</tr>
          </thead>
          <tbody>
            {visibleRows.map(({ row, key }) => <tr key={key} className={selected.has(key) ? 'selected-data-row' : ''}><td className="select-column"><input type="checkbox" checked={selected.has(key)} aria-label="Pilih baris" onChange={() => setSelected((current) => { const next = new Set(current); next.has(key) ? next.delete(key) : next.add(key); return next })} /></td>{columns.map((column) => <td key={column} title={asText(row[column])}>{asText(row[column])}</td>)}</tr>)}
          </tbody>
        </table>
      </div>
      <div className="pagination-row">
        <label>Tampilkan <select value={pageSize} onChange={(event) => { setPageSize(Number(event.target.value)); setPage(0) }}><option value={10}>10</option><option value={20}>20</option><option value={50}>50</option><option value={100}>100</option></select> baris</label>
        <span>Halaman {safePage + 1} dari {pageCount}</span>
        <div>
          <button type="button" aria-label="Halaman pertama" disabled={safePage === 0} onClick={() => setPage(0)}><ChevronsLeft size={17} /></button>
          <button type="button" aria-label="Halaman sebelumnya" disabled={safePage === 0} onClick={() => setPage(safePage - 1)}><ChevronLeft size={17} /></button>
          <button type="button" aria-label="Halaman berikutnya" disabled={safePage >= pageCount - 1} onClick={() => setPage(safePage + 1)}><ChevronRight size={17} /></button>
          <button type="button" aria-label="Halaman terakhir" disabled={safePage >= pageCount - 1} onClick={() => setPage(pageCount - 1)}><ChevronsRight size={17} /></button>
        </div>
      </div>
    </section>
  )
}
