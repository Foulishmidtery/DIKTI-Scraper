const { app, BrowserWindow, dialog } = require("electron");
const { spawn, spawnSync } = require("node:child_process");
const fs = require("node:fs");
const http = require("node:http");
const net = require("node:net");
const path = require("node:path");

let backendProcess = null;
let isQuitting = false;
let mainWindow = null;
let desktopLogPath = null;

const singleInstanceLock = app.requestSingleInstanceLock();
if (!singleInstanceLock) app.quit();

function writeDesktopLog(message) {
  const line = `${new Date().toISOString()} ${message}\n`;
  console.log(message);
  if (desktopLogPath) fs.appendFileSync(desktopLogPath, line);
}

function findFreePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.unref();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      const port = typeof address === "object" && address ? address.port : 5000;
      server.close(() => resolve(port));
    });
  });
}

function portableRoot() {
  if (!app.isPackaged) return path.resolve(__dirname, "..", "..");
  return process.env.PORTABLE_EXECUTABLE_DIR || path.dirname(process.execPath);
}

function prepareDataFiles() {
  let root = portableRoot();
  try {
    fs.mkdirSync(path.join(root, "data", "output"), { recursive: true });
  } catch {
    root = app.getPath("userData");
    fs.mkdirSync(path.join(root, "data", "output"), { recursive: true });
  }

  const envPath = path.join(root, ".env");
  if (!fs.existsSync(envPath) && app.isPackaged) {
    fs.copyFileSync(path.join(process.resourcesPath, ".env.example"), envPath);
  }
  desktopLogPath = path.join(root, "data", "logs", "desktop.log");
  fs.mkdirSync(path.dirname(desktopLogPath), { recursive: true });
  return { root, envPath, outputPath: path.join(root, "data", "output") };
}

function pythonCommand(appRoot) {
  if (app.isPackaged) {
    return {
      command: path.join(
        process.resourcesPath,
        "backend",
        "pddikti-backend.exe",
      ),
      args: [],
    };
  }

  const candidates = [
    process.env.PDDIKTI_PYTHON,
    path.resolve(appRoot, ".venv", "Scripts", "python.exe"),
    path.resolve(appRoot, "..", ".venv", "Scripts", "python.exe"),
  ].filter(Boolean);
  const command =
    candidates.find((candidate) => fs.existsSync(candidate)) || "py";
  return {
    command,
    args:
      command === "py"
        ? ["-3", "-m", "backend.desktop_entry"]
        : ["-m", "backend.desktop_entry"],
  };
}

function waitForBackend(url, child, timeoutMs = 45000) {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const check = () => {
      if (child.exitCode !== null)
        return reject(new Error("Backend berhenti sebelum siap."));
      const request = http.get(`${url}/api/health`, (response) => {
        response.resume();
        resolve();
      });
      request.setTimeout(1200, () => request.destroy());
      request.on("error", () => {
        if (Date.now() - started >= timeoutMs)
          return reject(new Error("Backend tidak merespons dalam 45 detik."));
        setTimeout(check, 350);
      });
    };
    check();
  });
}

async function startBackend(port, data) {
  const appRoot = portableRoot();
  const launch = pythonCommand(appRoot);
  const logDir = path.join(data.root, "data", "logs");
  fs.mkdirSync(logDir, { recursive: true });
  const log = fs.createWriteStream(path.join(logDir, "backend.log"), {
    flags: "a",
  });

  backendProcess = spawn(launch.command, launch.args, {
    cwd: appRoot,
    windowsHide: true,
    env: {
      ...process.env,
      FLASK_HOST: "127.0.0.1",
      FLASK_PORT: String(port),
      FLASK_DEBUG: "0",
      PDDIKTI_DESKTOP: "1",
      PDDIKTI_AUTH_KEY: "",
      PDDIKTI_ENV_FILE: data.envPath,
      PDDIKTI_OUTPUT_DIR: data.outputPath,
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  backendProcess.stdout.pipe(log);
  backendProcess.stderr.pipe(log);
  await waitForBackend(`http://127.0.0.1:${port}`, backendProcess);
}

function createWindow(apiBaseUrl) {
  writeDesktopLog(`[electron] API siap: ${apiBaseUrl}`);
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1080,
    minHeight: 700,
    show: true,
    backgroundColor: "#f7f8fa",
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      additionalArguments: [`--pddikti-api=${apiBaseUrl}`],
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  mainWindow.webContents.on("did-fail-load", (_event, code, description) => {
    writeDesktopLog(`[electron] UI gagal dimuat (${code}): ${description}`);
  });
  mainWindow.webContents.on("did-finish-load", () =>
    writeDesktopLog("[electron] UI berhasil dimuat"),
  );
  mainWindow.webContents.setZoomFactor(0.8);
  mainWindow.webContents.setVisualZoomLevelLimits(1, 1);
  mainWindow.webContents.on("before-input-event", (event, input) => {
    if (
      (input.control || input.meta) &&
      ["+", "-", "=", "0"].includes(input.key)
    )
      event.preventDefault();
  });
  mainWindow
    .loadFile(path.join(__dirname, "..", "dist", "index.html"))
    .then(() => {
      mainWindow.show();
      mainWindow.focus();
      writeDesktopLog("[electron] Jendela UI ditampilkan");
    })
    .catch((error) =>
      writeDesktopLog(`[electron] loadFile gagal: ${error.message}`),
    );
}

app.on("second-instance", () => {
  if (!mainWindow) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.focus();
});

if (singleInstanceLock)
  app.whenReady().then(async () => {
    try {
      const port = await findFreePort();
      const data = prepareDataFiles();
      const apiBaseUrl = `http://127.0.0.1:${port}`;
      await startBackend(port, data);
      createWindow(apiBaseUrl);
    } catch (error) {
      dialog.showErrorBox(
        "PDDIKTI Scraper gagal dimulai",
        `${error.message}\nPeriksa data/logs/backend.log.`,
      );
      app.quit();
    }
  });

app.on("window-all-closed", () => app.quit());
app.on("before-quit", () => {
  if (isQuitting) return;
  isQuitting = true;
  if (!backendProcess || backendProcess.exitCode !== null) return;
  if (process.platform === "win32") {
    spawnSync("taskkill", ["/pid", String(backendProcess.pid), "/t", "/f"], {
      windowsHide: true,
    });
  } else {
    backendProcess.kill();
  }
});
