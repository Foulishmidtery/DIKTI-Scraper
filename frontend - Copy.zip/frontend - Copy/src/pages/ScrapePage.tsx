import {
  Check,
  CheckCircle2,
  Clipboard,
  Download,
  LoaderCircle,
  Play,
  Search,
  ShieldCheck,
  Square,
  TerminalSquare,
  X,
} from 'lucide-react'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { ConfirmDialog, useToast } from '../components/Feedback'
import { api } from '../lib/api'
import type { StreamEvent } from '../types'

type RunState = 'idle' | 'starting' | 'running' | 'done' | 'error' | 'cancelled'

interface ProgressState {
  step: number
  current: number
  total: number
  label: string
}

export function ScrapePage({ databaseOnline, onOutputCreated }: { databaseOnline: boolean | null; onOutputCreated: () => void }) {
  const { pushToast } = useToast()
  const [targets, setTargets] = useState<string[]>([])
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [runState, setRunState] = useState<RunState>('idle')
  const [jobId, setJobId] = useState<string | null>(null)
  const [logs, setLogs] = useState<string[]>([])
  const [progress, setProgress] = useState<ProgressState>({ step: 0, current: 0, total: 1, label: 'Menunggu proses' })
  const [resultFile, setResultFile] = useState<string | null>(null)
  const eventSourceRef = useRef<EventSource | null>(null)
  const logEndRef = useRef<HTMLDivElement | null>(null)

  const loadTargets = useCallback(async () => {
    setLoading(true)
    setLoadError('')
    try {
      const response = await api.targets()
      setTargets(response.data)
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : 'Gagal memuat daftar program studi')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void loadTargets()
    return () => eventSourceRef.current?.close()
  }, [loadTargets])

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
  }, [logs])

  const filteredTargets = useMemo(() => {
    const query = search.trim().toLocaleLowerCase('id-ID')
    return query ? targets.filter((target) => target.toLocaleLowerCase('id-ID').includes(query)) : targets
  }, [search, targets])

  const selectedOrdered = useMemo(() => targets.filter((target) => selected.has(target)), [selected, targets])
  const isBusy = runState === 'starting' || runState === 'running'
  const progressPercent = progress.total > 0 ? Math.min(100, Math.round((progress.current / progress.total) * 100)) : 0

  const toggleTarget = (target: string) => {
    if (isBusy) return
    setSelected((current) => {
      const next = new Set(current)
      if (next.has(target)) next.delete(target)
      else next.add(target)
      return next
    })
  }

  const appendLog = (message: string) => setLogs((current) => [...current, message])

  const startStream = (id: string) => {
    eventSourceRef.current?.close()
    const source = new EventSource(api.streamUrl(id), { withCredentials: true })
    eventSourceRef.current = source
    source.onerror = () => {
      if (source.readyState !== EventSource.CLOSED) appendLog('Koneksi log terputus; mencoba tersambung kembali…')
    }
    source.onmessage = (message) => {
      const event = JSON.parse(message.data) as StreamEvent
      if (event.type === 'log') appendLog(event.message)
      if (event.type === 'progress') {
        setProgress({ step: event.step, current: event.current, total: event.total, label: event.label })
      }
      if (event.type === 'done') {
        source.close()
        setRunState('done')
        setJobId(null)
        setResultFile(event.filename)
        setProgress((current) => ({ ...current, current: current.total, label: 'Data selesai diproses' }))
        appendLog(`Selesai. File ${event.filename} siap diunduh.`)
        if (event.stats) {
          appendLog(`Ringkasan database: ${event.stats.dosen_inserted} dosen baru, ${event.stats.prodi_inserted} prodi baru.`)
          appendLog(`Duplikat dilewati: ${event.stats.dosen_skipped} dosen dan ${event.stats.prodi_skipped} prodi.`)
        }
        pushToast('Scraping selesai dan file Excel sudah tersedia.', 'success')
        onOutputCreated()
      }
      if (event.type === 'error') {
        source.close()
        const cancelled = event.message.toLocaleLowerCase('id-ID').includes('dihentikan')
        setRunState(cancelled ? 'cancelled' : 'error')
        setJobId(null)
        appendLog(cancelled ? 'Proses dihentikan sepenuhnya.' : `Gagal: ${event.message}`)
        pushToast(cancelled ? 'Scraping dibatalkan.' : event.message, cancelled ? 'info' : 'error')
      }
    }
  }

  const runScraper = async () => {
    setConfirmOpen(false)
    setRunState('starting')
    setLogs([])
    setResultFile(null)
    setProgress({ step: 0, current: 0, total: 1, label: 'Menyiapkan sinkronisasi katalog…' })
    try {
      const response = await api.startJob(selectedOrdered)
      setJobId(response.job_id)
      setRunState('running')
      appendLog(`${response.selected_total} program studi masuk antrean.`)
      startStream(response.job_id)
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal memulai scraper'
      setRunState('error')
      appendLog(message)
      pushToast(message, 'error')
    }
  }

  const stopScraper = async () => {
    if (!jobId) return
    try {
      await api.stopJob(jobId)
      appendLog('Sinyal berhenti dikirim ke engine. Menunggu proses aktif ditutup…')
    } catch (error) {
      pushToast(error instanceof Error ? error.message : 'Gagal menghentikan proses', 'error')
    }
  }

  const stateLabel: Record<RunState, string> = {
    idle: databaseOnline === false ? 'PostgreSQL belum siap' : selected.size ? `${selected.size} prodi siap diproses` : 'Pilih minimal 1 program studi',
    starting: 'Menyiapkan job…',
    running: 'Scraping sedang berjalan',
    done: 'Scraping selesai',
    error: 'Proses mengalami kendala',
    cancelled: 'Scraping dibatalkan',
  }

  return (
    <>
      <section className="intro-row">
        <div>
          <p className="eyebrow">Pengambilan data</p>
          <h2>Mulai dari prodi yang Anda butuhkan.</h2>
          <p className="lede">Katalog disinkronkan otomatis untuk pilihan Anda, lalu hasil dosen dan prodi disusun ke satu file Excel.</p>
        </div>
        <div className="run-summary">
          <span className={`run-indicator ${isBusy ? 'active' : ''}`} />
          <div><strong>{stateLabel[runState]}</strong><small>{targets.length || '—'} prodi tersedia</small></div>
        </div>
      </section>

      <div className="scrape-layout">
        <section className="panel target-panel">
          <div className="panel-heading">
            <div><span className="step-number">01</span><h3>Pilih program studi</h3></div>
            <span className="selection-count">{selected.size} / {targets.length} dipilih</span>
          </div>

          <label className="search-field">
            <Search size={18} />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Cari program studi…" />
            {search && <button type="button" aria-label="Hapus pencarian" onClick={() => setSearch('')}><X size={16} /></button>}
          </label>

          <div className="selection-toolbar">
            <span>{filteredTargets.length} hasil</span>
            <div>
              <button type="button" disabled={isBusy || !targets.length} onClick={() => setSelected(new Set(targets))}>Pilih semua</button>
              <button type="button" disabled={isBusy || !selected.size} onClick={() => setSelected(new Set())}>Kosongkan</button>
            </div>
          </div>

          <div className="target-list" aria-busy={loading}>
            {loading && <div className="inline-state"><LoaderCircle className="spin" size={22} /> Memuat whitelist prodi…</div>}
            {loadError && <div className="inline-error"><span>{loadError}</span><button type="button" onClick={() => void loadTargets()}>Coba lagi</button></div>}
            {!loading && !loadError && filteredTargets.map((target) => {
              const checked = selected.has(target)
              return (
                <button type="button" className={`target-row ${checked ? 'selected' : ''}`} key={target} aria-pressed={checked} onClick={() => toggleTarget(target)}>
                  <span className="checkbox-box">{checked && <Check size={14} strokeWidth={3} />}</span>
                  <span>{target}</span>
                  <small>{checked ? 'Dipilih' : 'Tersedia'}</small>
                </button>
              )
            })}
            {!loading && !loadError && filteredTargets.length === 0 && <div className="inline-state">Tidak ada program studi yang cocok.</div>}
          </div>

          <div className={`safety-note ${databaseOnline === false ? 'database-warning' : ''}`}>
            <ShieldCheck size={18} />
            <span>{databaseOnline === false ? 'Hubungkan PostgreSQL sebelum menjalankan scraper. Tidak ada job yang dimulai tanpa pengecekan database.' : 'Setiap hasil dibandingkan dengan PostgreSQL; record lama dilewati dan hanya record baru yang disimpan.'}</span>
          </div>
        </section>

        <section className="panel run-panel">
          <div className="panel-heading">
            <div><span className="step-number">02</span><h3>Jalankan scraper</h3></div>
            <span className={`status-badge status-${runState}`}>{stateLabel[runState]}</span>
          </div>

          <div className="process-map" aria-label="Tahapan proses">
            {['Sinkronisasi', 'Daftar dosen', 'Profil dosen', 'Simpan database', 'Ekspor Excel'].map((label, index) => (
              <div className={progress.step > index + 1 || runState === 'done' ? 'complete' : progress.step === index + 1 ? 'current' : ''} key={label}>
                <span>{progress.step > index + 1 || runState === 'done' ? <Check size={13} /> : index + 1}</span>
                <small>{label}</small>
              </div>
            ))}
          </div>

          <div className="progress-block">
            <div><span>{progress.label}</span><strong>{isBusy || runState === 'done' ? `${progressPercent}%` : '—'}</strong></div>
            <div className="progress-track"><span style={{ width: `${isBusy || runState === 'done' ? progressPercent : 0}%` }} /></div>
            <small>{isBusy ? `${progress.current} dari ${progress.total}` : 'Progress akan tampil setelah job dimulai'}</small>
          </div>

          <div className="run-actions">
            <button className="button primary wide" type="button" disabled={!selected.size || isBusy || databaseOnline === false} onClick={() => setConfirmOpen(true)}>
              {isBusy ? <LoaderCircle className="spin" size={18} /> : <Play size={18} fill="currentColor" />}
              {isBusy ? 'Sedang memproses…' : `Mulai scraping ${selected.size || ''}`}
            </button>
            {isBusy && <button className="button stop wide" type="button" onClick={() => void stopScraper()}><Square size={16} fill="currentColor" /> Batalkan scraping</button>}
            {resultFile && <a className="button success-button wide" href={api.downloadUrl(resultFile)}><Download size={18} /> Unduh hasil Excel</a>}
          </div>

          <div className="log-console">
            <div className="log-header">
              <span><TerminalSquare size={16} /> Log proses</span>
              <div>
                <button type="button" disabled={!logs.length} onClick={() => { void navigator.clipboard.writeText(logs.join('\n')); pushToast('Log disalin.', 'success') }}><Clipboard size={15} /> Salin</button>
                <button type="button" disabled={!logs.length || isBusy} onClick={() => setLogs([])}>Bersihkan</button>
              </div>
            </div>
            <div className="log-body" aria-live="polite">
              {!logs.length ? <span className="log-empty">Log akan muncul di sini setelah proses dimulai.</span> : logs.map((log, index) => <p key={`${index}-${log}`}>{log}</p>)}
              <div ref={logEndRef} />
            </div>
          </div>
        </section>
      </div>

      <ConfirmDialog
        open={confirmOpen}
        title="Mulai proses scraping?"
        description={`Katalog akan disinkronkan dan data akan diambil untuk ${selected.size} program studi terpilih.`}
        confirmLabel="Ya, mulai scraping"
        onCancel={() => setConfirmOpen(false)}
        onConfirm={() => void runScraper()}
      >
        <div className="confirm-list">
          {selectedOrdered.map((item) => <div key={item}><CheckCircle2 size={15} /><span>{item}</span></div>)}
        </div>
      </ConfirmDialog>
    </>
  )
}
