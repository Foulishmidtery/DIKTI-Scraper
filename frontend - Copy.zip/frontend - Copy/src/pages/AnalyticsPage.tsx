import { Database, LoaderCircle, RefreshCw } from 'lucide-react'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { DataTable, DistributionChart, MetricCard } from '../components/AnalyticsUI'
import { EmptyState } from '../components/EmptyState'
import { useToast } from '../components/Feedback'
import { api } from '../lib/api'
import { asNumber, countBy } from '../lib/format'
import type { AnalysisResponse } from '../types'

const DOSEN_COLUMNS = ['Nama', 'Perguruan Tinggi', 'Jabatan Fungsional', 'Jenis Kelamin', 'Pendidikan Terakhir', 'Status Kepegawaian', 'Jenjang']
const PRODI_COLUMNS = ['Nama Prodi', 'Jenjang', 'Perguruan Tinggi', 'Jumlah Dosen', 'Akreditasi Program Studi', 'PTN/PTS', 'Provinsi']

const percentage = (part: number, total: number) => total ? `${((part / total) * 100).toFixed(1)}%` : '0%'

export function AnalyticsPage({ type, revision }: { type: 'dosen' | 'prodi'; revision: number }) {
  const { pushToast } = useToast()
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null)
  const [loadingAnalysis, setLoadingAnalysis] = useState(true)
  const [error, setError] = useState('')

  const loadAnalysis = useCallback(async () => {
    setLoadingAnalysis(true)
    setError('')
    try {
      setAnalysis(await api.analytics())
    } catch (reason) {
      const message = reason instanceof Error ? reason.message : 'Gagal membaca analitik PostgreSQL'
      setError(message)
      setAnalysis(null)
      pushToast(message, 'error')
    } finally {
      setLoadingAnalysis(false)
    }
  }, [pushToast])

  useEffect(() => { void loadAnalysis() }, [loadAnalysis, revision])

  const rawRows = type === 'dosen' ? analysis?.dosen ?? [] : analysis?.prodi ?? []
  const rows = useMemo(() => type === 'prodi'
    ? rawRows.map((row) => ({
        ...row,
        'Akreditasi Program Studi': ({ A: 'Unggul', B: 'Baik Sekali', C: 'Baik' } as Record<string, string>)[String(row['Akreditasi Program Studi'] ?? '')] ?? row['Akreditasi Program Studi'],
      }))
    : rawRows, [rawRows, type])

  const view = type === 'dosen' ? buildDosenView(rows) : buildProdiView(rows)

  return (
    <>
      <section className="intro-row analytics-intro">
        <div>
          <p className="eyebrow">Intelijen data</p>
          <h2>{type === 'dosen' ? 'Profil tenaga pengajar dalam satu pandangan.' : 'Peta program studi dan institusi.'}</h2>
          <p className="lede">Metrik, distribusi, dan data rinci selalu dibaca langsung dari PostgreSQL.</p>
        </div>
      </section>

      <section className="analysis-selector panel">
        <div className="selector-icon"><Database size={21} /></div>
        <div className="database-source-copy"><span>Sumber data</span><strong>PostgreSQL · live dataset</strong><small>{analysis ? `${analysis.metadata.total_dosen.toLocaleString('id-ID')} dosen · ${analysis.metadata.total_prodi.toLocaleString('id-ID')} prodi` : 'Menunggu koneksi database'}</small></div>
        <button className="button secondary" type="button" onClick={() => void loadAnalysis()}><RefreshCw className={loadingAnalysis ? 'spin' : ''} size={17} /> Segarkan data</button>
      </section>

      {loadingAnalysis && <div className="analytics-loading"><LoaderCircle className="spin" size={28} /><strong>Menyiapkan analisis…</strong><span>Membaca dataset terbaru dari PostgreSQL.</span></div>}
      {!loadingAnalysis && error && <EmptyState title="Analisis belum dapat ditampilkan" description={error} action={<button className="button secondary" type="button" onClick={() => void loadAnalysis()}>Coba lagi</button>} />}
      {!loadingAnalysis && !error && analysis && !rows.length && <EmptyState title="Database masih kosong" description="Jalankan scraper atau impor file Excel lama untuk menambahkan data pertama." />}

      {!loadingAnalysis && !error && analysis && rows.length > 0 && (
        <>
          <div className="analytics-metric-grid">
            {view.metrics.map((metric) => <MetricCard key={metric.label} {...metric} />)}
          </div>
          <div className="chart-grid">
            {view.charts.map((chart) => <DistributionChart key={chart.title} {...chart} />)}
          </div>
          <DataTable key={`${type}-${revision}`} rows={rows} columns={type === 'dosen' ? DOSEN_COLUMNS : PRODI_COLUMNS} />
        </>
      )}
    </>
  )
}

function buildDosenView(rows: Record<string, unknown>[]) {
  const total = rows.length
  const male = rows.filter((row) => String(row['Jenis Kelamin'] ?? '').includes('Laki')).length
  const female = rows.filter((row) => String(row['Jenis Kelamin'] ?? '').includes('Perempuan')).length
  const s3 = rows.filter((row) => row['Pendidikan Terakhir'] === 'S3').length
  const professors = rows.filter((row) => row['Jabatan Fungsional'] === 'Profesor').length
  const permanent = rows.filter((row) => String(row['Status Ikatan Kerja'] ?? '').includes('Dosen Tetap')).length
  return {
    metrics: [
      { label: 'Total dosen', value: total.toLocaleString('id-ID'), detail: 'Tersimpan di PostgreSQL' },
      { label: 'Perempuan', value: female.toLocaleString('id-ID'), detail: `${percentage(female, total)} dari total` },
      { label: 'Laki-laki', value: male.toLocaleString('id-ID'), detail: `${percentage(male, total)} dari total` },
      { label: 'Doktor (S3)', value: percentage(s3, total), detail: `${s3.toLocaleString('id-ID')} dosen` },
      { label: 'Profesor', value: percentage(professors, total), detail: `${professors.toLocaleString('id-ID')} dosen` },
      { label: 'Dosen tetap', value: percentage(permanent, total), detail: `${permanent.toLocaleString('id-ID')} dosen` },
    ],
    charts: [
      { title: 'Komposisi gender', subtitle: 'Sebaran dosen berdasarkan jenis kelamin', data: countBy(rows, 'Jenis Kelamin'), kind: 'pie' as const },
      { title: 'Pendidikan terakhir', subtitle: 'Jenjang pendidikan tertinggi', data: countBy(rows, 'Pendidikan Terakhir') },
      { title: 'Jabatan fungsional', subtitle: 'Distribusi jenjang jabatan akademik', data: countBy(rows, 'Jabatan Fungsional') },
      { title: 'Status kepegawaian', subtitle: 'Kelompok status kepegawaian dosen', data: countBy(rows, 'Status Kepegawaian') },
      { title: 'Perguruan tinggi teratas', subtitle: '10 institusi dengan dosen terbanyak', data: countBy(rows, 'Perguruan Tinggi') },
      { title: 'Status aktivitas', subtitle: 'Kondisi aktivitas dosen saat data diambil', data: countBy(rows, 'Status Aktifitas') },
      { title: 'Ikatan kerja', subtitle: 'Sebaran hubungan kerja dosen', data: countBy(rows, 'Status Ikatan Kerja'), kind: 'pie' as const },
    ],
  }
}

function buildProdiView(rows: Record<string, unknown>[]) {
  const total = rows.length
  const institutions = new Set(rows.map((row) => String(row['Perguruan Tinggi'] ?? '')).filter(Boolean)).size
  const totalLecturers = rows.reduce((sum, row) => sum + asNumber(row['Jumlah Dosen']), 0)
  const excellent = rows.filter((row) => row['Akreditasi Program Studi'] === 'Unggul').length
  const notReported = rows.filter((row) => String(row['Semester Laporan Terakhir'] ?? '').toLocaleLowerCase('id-ID').includes('belum')).length
  return {
    metrics: [
      { label: 'Total prodi', value: total.toLocaleString('id-ID'), detail: 'Tersimpan di PostgreSQL' },
      { label: 'Perguruan tinggi', value: institutions.toLocaleString('id-ID'), detail: 'Institusi unik' },
      { label: 'Rata-rata dosen', value: total ? (totalLecturers / total).toFixed(1) : '0', detail: 'Per program studi' },
      { label: 'Akreditasi unggul', value: percentage(excellent, total), detail: `${excellent.toLocaleString('id-ID')} prodi` },
      { label: 'Belum melapor', value: percentage(notReported, total), detail: `${notReported.toLocaleString('id-ID')} prodi` },
    ],
    charts: [
      { title: 'Akreditasi program studi', subtitle: 'Komposisi peringkat akreditasi', data: countBy(rows, 'Akreditasi Program Studi'), kind: 'pie' as const },
      { title: 'Jenjang pendidikan', subtitle: 'Sebaran prodi menurut jenjang', data: countBy(rows, 'Jenjang') },
      { title: 'Provinsi teratas', subtitle: '10 wilayah dengan prodi terbanyak', data: countBy(rows, 'Provinsi') },
      { title: 'Status perguruan tinggi', subtitle: 'Perbandingan PTN dan PTS', data: countBy(rows, 'PTN/PTS'), kind: 'pie' as const },
      { title: 'Klasifikasi PTKIN', subtitle: 'Kelompok PTKIN dan non-PTKIN', data: countBy(rows, 'PTKIN/NON PTKIN'), kind: 'pie' as const },
      { title: 'Pengelola data', subtitle: 'Klasifikasi DIKTI dan DIKTIS', data: countBy(rows, 'DIKTI/DIKTIS'), kind: 'pie' as const },
      { title: 'Pelaporan semester', subtitle: 'Status laporan terakhir program studi', data: countBy(rows.map((row) => ({ status: String(row['Semester Laporan Terakhir'] ?? '').toLocaleLowerCase('id-ID').includes('belum') ? 'Belum lapor' : 'Sudah lapor' })), 'status'), kind: 'pie' as const },
    ],
  }
}
