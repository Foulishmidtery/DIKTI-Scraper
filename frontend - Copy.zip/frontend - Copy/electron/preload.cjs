const { contextBridge } = require('electron')

const apiArgument = process.argv.find((value) => value.startsWith('--pddikti-api='))
const apiBaseUrl = apiArgument ? apiArgument.slice('--pddikti-api='.length) : 'http://127.0.0.1:5000'

contextBridge.exposeInMainWorld('desktopApi', { apiBaseUrl })
