import { lazy, Suspense, useEffect, useState } from 'react'
import { AppShell } from './components/AppShell'
import { ToastProvider } from './components/Feedback'
import { api } from './lib/api'
import { FilesPage } from './pages/FilesPage'
import { ScrapePage } from './pages/ScrapePage'
import type { PageId } from './types'

const AnalyticsPage = lazy(() => import('./pages/AnalyticsPage').then((module) => ({ default: module.AnalyticsPage })))

const pageIds: PageId[] = ['scrape', 'files', 'dosen', 'prodi']

const pageFromHash = (): PageId => {
  const hash = window.location.hash.replace('#/', '') as PageId
  return pageIds.includes(hash) ? hash : 'scrape'
}

export default function App() {
  const [page, setPage] = useState<PageId>(pageFromHash)
  const [apiOnline, setApiOnline] = useState<boolean | null>(null)
  const [databaseOnline, setDatabaseOnline] = useState<boolean | null>(null)
  const [outputRevision, setOutputRevision] = useState(0)

  useEffect(() => {
    const onHashChange = () => setPage(pageFromHash())
    window.addEventListener('hashchange', onHashChange)
    if (!window.location.hash) window.history.replaceState(null, '', '#/scrape')
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  useEffect(() => {
    let active = true
    const checkApi = () => api.health()
      .then((health) => {
        if (active) {
          setApiOnline(true)
          setDatabaseOnline(health.database.connected)
        }
      })
      .catch(() => {
        if (active) {
          setApiOnline(false)
          setDatabaseOnline(false)
        }
      })
    void checkApi()
    const interval = window.setInterval(checkApi, 5_000)
    window.addEventListener('focus', checkApi)
    return () => {
      active = false
      window.clearInterval(interval)
      window.removeEventListener('focus', checkApi)
    }
  }, [])

  const navigate = (nextPage: PageId) => {
    window.location.hash = `/${nextPage}`
    setPage(nextPage)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <ToastProvider>
      <AppShell activePage={page} apiOnline={apiOnline} databaseOnline={databaseOnline} onNavigate={navigate}>
        <div className={page === 'scrape' ? '' : 'route-hidden'} aria-hidden={page !== 'scrape'}>
          <ScrapePage databaseOnline={databaseOnline} onOutputCreated={() => setOutputRevision((value) => value + 1)} />
        </div>
        {page === 'files' && <FilesPage revision={outputRevision} onNavigate={navigate} />}
        {(page === 'dosen' || page === 'prodi') && (
          <Suspense fallback={<div className="analytics-loading"><strong>Menyiapkan modul analisis…</strong></div>}>
            <AnalyticsPage type={page} revision={outputRevision} />
          </Suspense>
        )}
      </AppShell>
    </ToastProvider>
  )
}
