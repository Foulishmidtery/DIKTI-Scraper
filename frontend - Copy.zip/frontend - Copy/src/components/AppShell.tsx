import {
  BarChart3,
  Database,
  Files,
  GraduationCap,
  Menu,
  PanelLeftClose,
  Sparkles,
  X,
} from 'lucide-react'
import { useState, type ReactNode } from 'react'
import type { PageId } from '../types'

const navigation: Array<{
  id: PageId
  label: string
  eyebrow: string
  icon: typeof Database
}> = [
  { id: 'scrape', label: 'Scraping', eyebrow: 'Koleksi data', icon: Database },
  { id: 'files', label: 'Hasil & riwayat', eyebrow: 'Riwayat database', icon: Files },
  { id: 'dosen', label: 'Analisis dosen', eyebrow: 'Profil SDM', icon: BarChart3 },
  { id: 'prodi', label: 'Analisis prodi', eyebrow: 'Pemetaan institusi', icon: GraduationCap },
]

interface AppShellProps {
  activePage: PageId
  apiOnline: boolean | null
  databaseOnline: boolean | null
  children: ReactNode
  onNavigate: (page: PageId) => void
}

export function AppShell({ activePage, apiOnline, databaseOnline, children, onNavigate }: AppShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const current = navigation.find((item) => item.id === activePage) ?? navigation[0]

  const navigate = (page: PageId) => {
    onNavigate(page)
    setMobileOpen(false)
  }

  return (
    <div className="app-shell">
      <button
        className="mobile-menu-button"
        type="button"
        aria-label="Buka menu"
        onClick={() => setMobileOpen(true)}
      >
        <Menu size={21} />
      </button>

      {mobileOpen && (
        <button
          type="button"
          className="sidebar-scrim"
          aria-label="Tutup menu"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
        <div className="brand-lockup">
          <div className="brand-mark" aria-hidden="true">
            <Sparkles size={20} />
          </div>
          <div>
            <strong>PDDIKTI</strong>
            <span>Data Workspace</span>
          </div>
          <button
            className="sidebar-close"
            type="button"
            aria-label="Tutup menu"
            onClick={() => setMobileOpen(false)}
          >
            <X size={19} />
          </button>
        </div>

        <div className="sidebar-label">Workspace</div>
        <nav className="sidebar-nav" aria-label="Navigasi utama">
          {navigation.map(({ id, label, eyebrow, icon: Icon }) => (
            <button
              type="button"
              key={id}
              className={activePage === id ? 'nav-link active' : 'nav-link'}
              onClick={() => navigate(id)}
            >
              <span className="nav-icon"><Icon size={18} /></span>
              <span>
                <strong>{label}</strong>
                <small>{eyebrow}</small>
              </span>
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className={`api-state ${apiOnline === false ? 'offline' : ''}`}>
            <span className="status-dot" />
            <div>
              <strong>{apiOnline === null ? 'Memeriksa API' : apiOnline ? 'API terhubung' : 'API tidak terhubung'}</strong>
              <small>Flask · localhost:5000</small>
            </div>
          </div>
          <div className={`api-state database-state ${databaseOnline === false ? 'offline' : ''}`}>
            <span className="status-dot" />
            <div>
              <strong>{databaseOnline === null ? 'Memeriksa database' : databaseOnline ? 'PostgreSQL terhubung' : 'PostgreSQL belum siap'}</strong>
              <small>Sumber data utama</small>
            </div>
          </div>
          <div className="version-row"><span>Workspace</span><span>v2.0</span></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div>
            <div className="breadcrumb"><span>Workspace</span><span>/</span><strong>{current.label}</strong></div>
            <h1>{current.label}</h1>
          </div>
          <div className="topbar-meta">
            <PanelLeftClose size={17} />
            <span>Data PDDIKTI</span>
          </div>
        </header>
        <div className="page-content">{children}</div>
      </main>
    </div>
  )
}
