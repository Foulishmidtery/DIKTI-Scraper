import type {
  AnalysisResponse,
  HealthResponse,
  OutputFile,
  ScrapeRunsResponse,
  StartJobResponse,
  TargetProdiResponse,
} from '../types'

const API_ORIGIN = (
  window.desktopApi?.apiBaseUrl ?? import.meta.env.VITE_API_BASE_URL ?? ''
).replace(/\/$/, '')

export const apiUrl = (path: string) => `${API_ORIGIN}${path}`

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(apiUrl(path), {
    credentials: 'include',
    ...options,
    headers: {
      ...(options?.body ? { 'Content-Type': 'application/json' } : {}),
      ...options?.headers,
    },
  })

  const body = (await response.json().catch(() => ({}))) as { error?: string }
  if (!response.ok) {
    throw new Error(body.error || `Permintaan gagal (${response.status})`)
  }
  return body as T
}

export const api = {
  health: () => request<HealthResponse>('/api/health'),
  targets: () => request<TargetProdiResponse>('/api/target-prodi'),
  outputs: () => request<OutputFile[]>('/api/outputs'),
  scrapeRuns: () => request<ScrapeRunsResponse>('/api/scrape-runs?limit=500'),
  analyze: (filename: string) =>
    request<AnalysisResponse>(`/api/analyze/${encodeURIComponent(filename)}`),
  analytics: () => request<AnalysisResponse>('/api/analytics'),
  exportDatabase: () => request<{ success: true; filename: string; size: number; modified: number }>('/api/export', { method: 'POST' }),
  startJob: (prodi: string[]) =>
    request<StartJobResponse>('/api/run-scraper', {
      method: 'POST',
      body: JSON.stringify({ prodi }),
    }),
  stopJob: (jobId: string) =>
    request<{ success: true; message: string }>(`/api/stop-scraper/${jobId}`, {
      method: 'POST',
    }),
  deleteOutput: (filename: string) =>
    request<{ success: true }>(`/api/delete-file/${encodeURIComponent(filename)}`, {
      method: 'DELETE',
    }),
  downloadUrl: (filename: string) => apiUrl(`/api/download/${encodeURIComponent(filename)}`),
  streamUrl: (jobId: string) => apiUrl(`/api/stream/${jobId}`),
}
