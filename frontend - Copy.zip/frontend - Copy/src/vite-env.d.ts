/// <reference types="vite/client" />

interface Window {
  desktopApi?: {
    apiBaseUrl: string
  }
}
